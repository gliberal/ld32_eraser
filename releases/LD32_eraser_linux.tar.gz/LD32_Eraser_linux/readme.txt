AUTHORS
=======

This game was created for LD32 by Céline Libéral (@cel_reloaded) & Zoé Belleton (@zoe_gfx).

REQUIREMENTS
============

In order to play this game, you will have to install libsdl2, libsdl2_image, libsdl2_mixer and libsdl2_ttf.

On ArchLinux
```
pacman -S sdl2 sdl2_image sdl2_mixer sdl2_ttf
```

On Ubuntu-like distribution
```
apt-get install libsdl2-dev libsdl2-image-dev libsdl2-mixer-dev libsdl2-ttf-dev
```

On Fedora-like distribution
```
yum install SDL2 SDL2-dev SDL2-image SDL2-image-devel SDL2-mixer SDL2-mixer-devel SDL2-ttf SDL2-ttf-devel
```

On OpenSuse
```
zypper install libsdl2-devel libsdl2_image-devel libsdl2_mixer-devel libsdl2_ttf-devel
```

On Debian & OpenBSD (and probably on other Linux / BSD), you have to compile SDL2 libs by yourself.
