LD32 - Eraser
=============

For Mac users, you have to copy Frameworks contents into /Library/Frameworks.

Authors
-------

This game has been created by Céline Libéral & Zoé Belleton known as Celisoft team.
You can find us on twitter : @cel_reloaded & @zoe_gfx

